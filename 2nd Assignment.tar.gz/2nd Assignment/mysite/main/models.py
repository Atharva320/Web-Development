from django.db import models
import datetime
import os
# Create your models here.
class User(models.Model):
    id=models.AutoField(primary_key=True)
    Firstname=models.CharField(max_length=30)
    Lastname=models.CharField(max_length=30)
    Email=models.CharField(max_length=30)
    City=models.CharField(max_length=30)
    Birthdate=models.CharField(max_length=30)
    Mob=models.CharField(max_length=30)
class Admin(models.Model):
    id=models.AutoField(primary_key=True)
    Firstname=models.CharField(max_length=30)
    Lastname=models.CharField(max_length=30)
    Email=models.CharField(max_length=30)
    Userid=models.CharField(max_length=30)
    Password=models.CharField(max_length=30)
class Image(models.Model):
    CarType = models.CharField(max_length=200,null=True, blank=True)
    Car_Company = models.CharField(max_length=200,null=True, blank=True)
    image = models.ImageField(upload_to='images',null=True, blank=True)
    def __str__(self):
        return self.Car_Company
    class Meta:
        db_table = "myapp_image"