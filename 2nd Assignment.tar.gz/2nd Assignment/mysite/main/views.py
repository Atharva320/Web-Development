from .models import User
from django.shortcuts import render,redirect
from operator import itemgetter
import pymysql
from django.contrib import messages
from .models import Image
from .forms import ImageForm
import uuid
from django.contrib.auth import logout
# Create your views here.
def welcome(request):
	return render(request, 'index.html')
def login(request):
	con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
	curs=con.cursor()
	con2=con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
	curs2=con2.cursor()
	con3=con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
	curs3=con2.cursor()
	sq1="select Email from Customers"
	sq2="select Firstname from Customers"
	sq3="select Lastname from Customers"
	curs.execute(sq1)
	curs2.execute(sq2)
	curs3.execute(sq3)
	e=[]
	f=[]
	l=[]
	for i in curs:
		e.append(i)
	for j in curs2:
		f.append(j)
	for n in curs3:
		l.append(n)
	res=list(map(itemgetter(0),e))
	res1=list(map(itemgetter(0),f))
	res2=list(map(itemgetter(0),l))
	if request.method == 'POST':
		email = request.POST.get('Email')
		first_name = request.POST.get('Firstname')
		last_name=request.POST.get('Lastname')
		i=0
		k=len(res)
		while i<k:
			if res[i]==email and res1[i]==first_name and res2[i]==last_name:
				return render(request, 'options.html',{'name' : first_name })
				break
			i+=1
		else:
			messages.error(request, "Invalid Details")
			return redirect('Home')
	return render(request, 'login.html')
def register(request):
	try:
		if request.method == "POST":
			Firstname = request.POST.get('Firstname')
			Lastname = request.POST.get('Lastname')
			Email = request.POST.get('Email')
			Mob = request.POST.get('Mob')
			City = request.POST.get('City')
			Birthdate = int(request.POST.get('Birthdate'))
			Id=str(uuid.uuid4().fields[-1])[:3]
			nId="FUA"+Id
			con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
			curs=con.cursor()
			sq2="insert into Customers values('%s','%s','%s','%s','%s','%d','%s')"%(Firstname,Lastname,Email,Mob,City,Birthdate,nId)
			curs.execute(sq2)
			con.commit()
			con.close()
			return render(request, 'Added.html',{'Data':nId})
	except:
		messages.error(request, "Some eror occurred")
	return render(request, 'register.html')
def Home(request):
	return render(request, 'Home.html')
	
def login_as_admin(request):
	con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
	curs=con.cursor()
	con2=con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
	curs2=con2.cursor()
	sq1="select Username from User"
	sq2="select Password from User"
	curs.execute(sq1)
	curs2.execute(sq2)
	u=[]
	p=[]
	for i in curs:
		u.append(i)
	for j in curs2:
		p.append(j)
	res=list(map(itemgetter(0),u))
	res1=list(map(itemgetter(0),p))
	if request.method == 'POST':
		userid = request.POST.get('Userid')
		password = request.POST.get('Password')
		i=0
		k=len(res)
		while i<k:
			if res[i]==userid and res1[i]==password:
				return render(request, 'index.html')
				break
			i+=1
		else:
			messages.error(request, "Invalid Admin details")
			return redirect('Home')
	return render(request, 'Admin.html')
def Advanced(request):
	return render(request, 'advanced.html')
def SomeFunction(request):
	if request.method=="POST":
		toy=0
		toy1=[]
		volks=0
		tes=0
		mer=0
		bmw=0
		ford=0
		n=request.POST.get('pos')
		if n=='Toyota':
			toy=toy+1
			toy1.append(toy)
			print(toy1)
			con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
			curs=con.cursor()
			sq1="select CarName,Price,Company from Cars where Company='%s'"%(n)
			curs.execute(sq1)
			data=curs.fetchall()
			res=list(map(itemgetter(0),data))
			con1=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
			curs1=con.cursor()
			sq2="select Car_Company from myapp_image"
			curs1.execute(sq2)
			rec=list(map(itemgetter(0),curs1))
			# for items in res:
			# 	for item in rec:
			# 		if items==item:
			rec2=[]
			con2=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
			curs2=con.cursor()
			sq3=Image.objects.filter(Car_Company__startswith='Toyota')
			for i in sq3:
				rec2.append(i.image)
			
			kuch=[]
			for i in range(len(data)):
				dt=list(data[i])
				kuch.append(dt)
			for i in range(len(kuch)):
				kuch[i].append(rec2[i])
			name=list(map(itemgetter(0),kuch))
			price=list(map(itemgetter(1),kuch))
			company=list(map(itemgetter(2),kuch))
			img=list(map(itemgetter(3),kuch))
			l=zip(name,price,company,img)
			return render(request, 'Costumer.html',{'data':l})
		elif n=='Tesla':
			tes+=1
			con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
			curs=con.cursor()
			sq1="select CarName,Price,Company from Cars where Company='%s'"%(n)
			curs.execute(sq1)
			data=curs.fetchall()
			res=list(map(itemgetter(0),data))
			con1=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
			curs1=con.cursor()
			sq2="select Car_Company from myapp_image"
			curs1.execute(sq2)
			rec=list(map(itemgetter(0),curs1))
			# for items in res:
			# 	for item in rec:
			# 		if items==item:
			rec2=[]
			con2=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
			curs2=con.cursor()
			sq3=Image.objects.filter(Car_Company__startswith='Tesla')
			for i in sq3:
				rec2.append(i.image)
			
			kuch=[]
			for i in range(len(data)):
				dt=list(data[i])
				kuch.append(dt)
			for i in range(len(kuch)):
				kuch[i].append(rec2[i])
			name=list(map(itemgetter(0),kuch))
			price=list(map(itemgetter(1),kuch))
			company=list(map(itemgetter(2),kuch))
			img=list(map(itemgetter(3),kuch))
			a=zip(name,price,company,img)
			return render(request, 'Costumer.html',{'data1':a})
		elif n=='Volkswagen':
			volks+=1
			con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
			curs=con.cursor()
			sq1="select CarName,Price,Company from Cars where Company='%s'"%(n)
			curs.execute(sq1)
			data=curs.fetchall()
			res=list(map(itemgetter(0),data))
			con1=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
			curs1=con.cursor()
			sq2="select Car_Company from myapp_image"
			curs1.execute(sq2)
			rec=list(map(itemgetter(0),curs1))
			# for items in res:
			# 	for item in rec:
			# 		if items==item:
			rec2=[]
			con2=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
			curs2=con.cursor()
			sq3=Image.objects.filter(Car_Company__startswith='Volkswagen')
			for i in sq3:
				rec2.append(i.image)
			
			kuch=[]
			for i in range(len(data)):
				dt=list(data[i])
				kuch.append(dt)
			for i in range(len(kuch)):
				kuch[i].append(rec2[i])
			name=list(map(itemgetter(0),kuch))
			price=list(map(itemgetter(1),kuch))
			company=list(map(itemgetter(2),kuch))
			img=list(map(itemgetter(3),kuch))
			b=zip(name,price,company,img)
			return render(request, 'Costumer.html',{'data2':b})	
		elif n=='Mercedes':
			mer+=1
			con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
			curs=con.cursor()
			sq1="select CarName,Price,Company from Cars where Company='%s'"%(n)
			curs.execute(sq1)
			data=curs.fetchall()
			res=list(map(itemgetter(0),data))
			con1=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
			curs1=con.cursor()
			sq2="select Car_Company from myapp_image"
			curs1.execute(sq2)
			rec=list(map(itemgetter(0),curs1))
			# for items in res:
			# 	for item in rec:
			# 		if items==item:
			rec2=[]
			con2=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
			curs2=con.cursor()
			sq3=Image.objects.filter(Car_Company__startswith='Mercedes')
			for i in sq3:
				rec2.append(i.image)
			
			kuch=[]
			for i in range(len(data)):
				dt=list(data[i])
				kuch.append(dt)
			for i in range(len(kuch)):
				kuch[i].append(rec2[i])
			name=list(map(itemgetter(0),kuch))
			price=list(map(itemgetter(1),kuch))
			company=list(map(itemgetter(2),kuch))
			img=list(map(itemgetter(3),kuch))
			c=zip(name,price,company,img)
			return render(request, 'Costumer.html',{'data3':c})	
		elif n=='BMW':
			bmw+=1
			con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
			curs=con.cursor()
			sq1="select CarName,Price,Company from Cars where Company='%s'"%(n)
			curs.execute(sq1)
			data=curs.fetchall()
			res=list(map(itemgetter(0),data))
			con1=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
			curs1=con.cursor()
			sq2="select Car_Company from myapp_image"
			curs1.execute(sq2)
			rec=list(map(itemgetter(0),curs1))
			# for items in res:
			# 	for item in rec:
			# 		if items==item:
			rec2=[]
			con2=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
			curs2=con.cursor()
			sq3=Image.objects.filter(Car_Company__startswith='BMW')
			for i in sq3:
				rec2.append(i.image)
			
			kuch=[]
			for i in range(len(data)):
				dt=list(data[i])
				kuch.append(dt)
			for i in range(len(kuch)):
				kuch[i].append(rec2[i])
			name=list(map(itemgetter(0),kuch))
			price=list(map(itemgetter(1),kuch))
			company=list(map(itemgetter(2),kuch))
			img=list(map(itemgetter(3),kuch))
			d=zip(name,price,company,img)
			return render(request, 'Costumer.html',{'data4':d})
		elif n=='Ford':
			ford+=1
			con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
			curs=con.cursor()
			sq1="select CarName,Price,Company from Cars where Company='%s'"%(n)
			curs.execute(sq1)
			data=curs.fetchall()
			res=list(map(itemgetter(0),data))
			con1=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
			curs1=con.cursor()
			sq2="select Car_Company from myapp_image"
			curs1.execute(sq2)
			rec=list(map(itemgetter(0),curs1))
			# for items in res:
			# 	for item in rec:
			# 		if items==item:
			rec2=[]
			con2=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
			curs2=con.cursor()
			sq3=Image.objects.filter(Car_Company__startswith='Ford')
			for i in sq3:
				rec2.append(i.image)
			
			kuch=[]
			for i in range(len(data)):
				dt=list(data[i])
				kuch.append(dt)
			for i in range(len(kuch)):
				kuch[i].append(rec2[i])
			name=list(map(itemgetter(0),kuch))
			price=list(map(itemgetter(1),kuch))
			company=list(map(itemgetter(2),kuch))
			img=list(map(itemgetter(3),kuch))
			e=zip(name,price,company,img)
			return render(request, 'Costumer.html',{'data5':e})	
	return render(request, 'Costumer.html')
def showimage(request):
    """Process images uploaded by users"""
    if request.method == 'POST' or request.method==None:
        form = ImageForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            # Get the current instance object to display in the template
            img_obj = form.instance
            return render(request, 'images.html', {'form': form, 'img_obj': img_obj})
    else:
        form = ImageForm()
    return render(request, 'images.html', {'form': form})
def ShowCars(request):
	con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
	curs=con.cursor()
	sq1="select CarName,Price,Company from Cars"
	curs.execute(sq1)
	data=curs.fetchall()
	res=list(map(itemgetter(0),data))
	con1=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
	curs1=con.cursor()
	sq2="select Car_Company from myapp_image"
	curs1.execute(sq2)
	rec=list(map(itemgetter(0),curs1))
	# for items in res:
	# 	for item in rec:
	# 		if items==item:
	rec2=[]
	con2=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
	curs2=con.cursor()
	sq3=Image.objects.all()
	for i in sq3:
		rec2.append(i.image)
	
	kuch=[]
	for i in range(len(data)):
		dt=list(data[i])
		kuch.append(dt)
	for i in range(len(kuch)):
		kuch[i].append(rec2[i])
	name=list(map(itemgetter(0),kuch))
	price=list(map(itemgetter(1),kuch))
	company=list(map(itemgetter(2),kuch))
	img=list(map(itemgetter(3),kuch))
	f=zip(name,price,company,img)
	return render(request, 'Showcars.html',{'data6':f})	
def Typewise(request):
	hatch=request.POST.get("Hatchback")
	suv=request.POST.get('SUV')
	sedan=request.POST.get('Sedan')
	muv=request.POST.get('MUV')
	conver=request.POST.get('Convertible')
	if hatch=="Hatchback":
		con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
		curs=con.cursor()
		sq1="select CarName,Price,Company from Cars where Cartype='%s'"%(hatch)
		curs.execute(sq1)
		data=curs.fetchall()
		res=list(map(itemgetter(0),data))
		rec2=[]
		con2=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
		curs2=con.cursor()
		sq3="select image from myapp_image where Cartype='%s'"%(hatch)
		curs2.execute(sq3)
		rec1=curs2.fetchall()
		rec2=[]
		for items in rec1:
			rec2.append(items)
		kuch=[]
		for i in range(len(data)):
			dt=list(data[i])
			kuch.append(dt)
		for i in range(len(kuch)):
			kuch[i].append(rec2[i])
		name=list(map(itemgetter(0),kuch))
		price=list(map(itemgetter(1),kuch))
		company=list(map(itemgetter(2),kuch))
		img=list(map(itemgetter(3),kuch))
		l=zip(name,price,company,img)
		return render(request, 'Typewise.html',{'data':l})
	elif suv=="SUV":
		con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
		curs=con.cursor()
		sq1="select CarName,Price,Company from Cars where Cartype='%s'"%(suv)
		curs.execute(sq1)
		data=curs.fetchall()
		res=list(map(itemgetter(0),data))
		rec2=[]
		con2=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
		curs2=con.cursor()
		sq3="select image from myapp_image where Cartype='%s'"%(suv)
		curs2.execute(sq3)
		rec1=curs2.fetchall()
		rec2=[]
		for items in rec1:
			rec2.append(items)
		kuch=[]
		for i in range(len(data)):
			dt=list(data[i])
			kuch.append(dt)
		for i in range(len(kuch)):
			kuch[i].append(rec2[i])
		name=list(map(itemgetter(0),kuch))
		price=list(map(itemgetter(1),kuch))
		company=list(map(itemgetter(2),kuch))
		img=list(map(itemgetter(3),kuch))
		l=zip(name,price,company,img)
		return render(request, 'Typewise.html',{'data':l})
	elif sedan=="Sedan":
		con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
		curs=con.cursor()
		sq1="select CarName,Price,Company from Cars where Cartype='%s'"%(sedan)
		curs.execute(sq1)
		data=curs.fetchall()
		res=list(map(itemgetter(0),data))
		rec2=[]
		con2=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
		curs2=con.cursor()
		sq3="select image from myapp_image where Cartype='%s'"%(sedan)
		curs2.execute(sq3)
		rec1=curs2.fetchall()
		rec2=[]
		for items in rec1:
			rec2.append(items)
		kuch=[]
		for i in range(len(data)):
			dt=list(data[i])
			kuch.append(dt)
		for i in range(len(kuch)):
			kuch[i].append(rec2[i])
		name=list(map(itemgetter(0),kuch))
		price=list(map(itemgetter(1),kuch))
		company=list(map(itemgetter(2),kuch))
		img=list(map(itemgetter(3),kuch))
		l=zip(name,price,company,img)
		return render(request, 'Typewise.html',{'data':l})
	elif muv=="MUV":
		con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
		curs=con.cursor()
		sq1="select CarName,Price,Company from Cars where Cartype='%s'"%(muv)
		curs.execute(sq1)
		data=curs.fetchall()
		res=list(map(itemgetter(0),data))
		rec2=[]
		con2=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
		curs2=con.cursor()
		sq3="select image from myapp_image where Cartype='%s'"%(muv)
		curs2.execute(sq3)
		rec1=curs2.fetchall()
		rec2=[]
		for items in rec1:
			rec2.append(items)
		kuch=[]
		for i in range(len(data)):
			dt=list(data[i])
			kuch.append(dt)
		for i in range(len(kuch)):
			kuch[i].append(rec2[i])
		name=list(map(itemgetter(0),kuch))
		price=list(map(itemgetter(1),kuch))
		company=list(map(itemgetter(2),kuch))
		img=list(map(itemgetter(3),kuch))
		l=zip(name,price,company,img)
		return render(request, 'Typewise.html',{'data':l})
	elif conver=="Convertible":
		con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
		curs=con.cursor()
		sq1="select CarName,Price,Company from Cars where Cartype='%s'"%(conver)
		curs.execute(sq1)
		data=curs.fetchall()
		res=list(map(itemgetter(0),data))
		rec2=[]
		con2=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
		curs2=con.cursor()
		sq3="select image from myapp_image where Cartype='%s'"%(conver)
		curs2.execute(sq3)
		rec1=curs2.fetchall()
		rec2=[]
		for items in rec1:
			rec2.append(items)
		kuch=[]
		for i in range(len(data)):
			dt=list(data[i])
			kuch.append(dt)
		for i in range(len(kuch)):
			kuch[i].append(rec2[i])
		name=list(map(itemgetter(0),kuch))
		price=list(map(itemgetter(1),kuch))
		company=list(map(itemgetter(2),kuch))
		img=list(map(itemgetter(3),kuch))
		l=zip(name,price,company,img)
		return render(request, 'Typewise.html',{'data':l})
	return render(request, 'Typewise.html')

def NewCar(request):
	if request.method =="POST":
		CarName=request.POST.get("Carname")
		wheels=int(request.POST.get("wheels"))
		fuel=request.POST.get("Fuel")
		Cartype=request.POST.get("Cartype")
		price=request.POST.get("Price")
		company=request.POST.get("Company")
		capacity=request.POST.get("capacity")
		con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
		curs=con.cursor()
		sq1="insert into Cars values('%d','%s','%s','%s','%s','%s','%s')"%(wheels,capacity,company,fuel,price,Cartype,CarName)
		curs.execute(sq1)
		con.commit()
		con.close()
		# return showimage(request)
	return render(request, 'Newcar.html')


def ModifyPrice(request):
	if request.method =="POST":
		name=request.POST.get('Carname')
		price=request.POST.get('Price')
		con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
		curs=con.cursor()
		sq2="update Cars set Price='%s' where CarName='%s'"%(price,name)
		curs.execute(sq2)
		con.commit()
		con.close()
		messages.success(request, "Price updated successfully")
	# else:
	# 	messages.error(request, "Something went Wrong")
	return render(request, 'modifycar.html')

def SearchCoust(request):
	if request.method =="POST":
		mix=request.POST.get("Name")
		con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
		curs=con.cursor()
		sq="select Firstname,CustomerId from Customers"
		curs.execute(sq)
		data=curs.fetchall()
		name=list(map(itemgetter(0),data))
		uid=list(map(itemgetter(1),data))
		for items in name:
			if items==mix:
				con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
				curs=con.cursor()
				sq="select * from Customers where Firstname='%s'"%(mix)
				curs.execute(sq)
				data=curs.fetchall()
				print(data)
				return render(request, 'searcbyname.html',{'data':data})
		for items in uid:
			if items==mix:
				con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
				curs=con.cursor()
				sq="select * from Customers where CustomerId='%s'"%(mix)
				curs.execute(sq)
				data=curs.fetchall()
				return render(request, 'searcbyname.html',{'data':data})
	return render(request, 'searcbyname.html')


def Most(request):
	return render(request, 'most.html')

def SearchCar(request):
	try:
		if request.method =="POST":
			name=request.POST.get("Name")
			con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
			curs=con.cursor()
			sq="select CarName,Price,Company from Cars where CarName='%s'"%(name)
			curs.execute(sq)
			data=curs.fetchall()
			con1=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
			curs1=con1.cursor()
			sq1=Image.objects.filter(Car_Company=name)
			rec=[]
			for i in sq1:
				rec.append(i.image)
			kuch=[]
			for i in range(len(data)):
				dt=list(data[i])
				kuch.append(dt)
			for i in range(len(kuch)):
				kuch[i].append(rec[i])
			name=list(map(itemgetter(0),kuch))
			price=list(map(itemgetter(1),kuch))
			company=list(map(itemgetter(2),kuch))
			img=list(map(itemgetter(3),kuch))
			a=zip(name,price,company,img)
			return render(request, 'searchcar.html',{'data':a})
	except:
			messages.error(request, "Some error occured")
	return render(request, 'searchcar.html')

def ListCousts(request):
	con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
	curs=con.cursor()
	sq="select Firstname,Lastname,CustomerId from Customers"
	curs.execute(sq)
	data=curs.fetchall()
	return render(request, 'listofcoust.html',{'data':data})
def Modifycoust(request):
	if request.method =="POST":
		name=request.POST.get('Name')
		City= request.POST.get('city')
		Mob= request.POST.get('mob')
		display_type = request.POST.getlist("check[]", None)
		print(display_type)
		if ('1' in display_type):
			con1=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
			curs1=con1.cursor()
			sq1="update Customers set Mobile='%s' where Firstname='%s'"%(Mob,name)
			curs1.execute(sq1)
			con1.commit()
			messages.success(request, "Mobile number updated successfully")
		if ('2' in display_type):
			Age= int(request.POST.get('Age'))
			con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
			curs=con.cursor()
			sq="update Customers set Age=%d where Firstname='%s'"%(Age,name)
			curs.execute(sq)
			con.commit()
			messages.success(request, "Age updated successfully")
		if ('3' in display_type):
			con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
			curs=con.cursor()
			sq="update Customers set City='%s' where Firstname='%s'"%(City,name)
			curs.execute(sq)
			con.commit()
			messages.success(request, "City update successfully")
	return render(request, 'modifydetails.html')


def logout_view(request):
    logout(request)
    return redirect('Home')

def Options(request):
	return render(request,'options.html')


