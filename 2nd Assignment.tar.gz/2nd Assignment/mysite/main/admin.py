from django.contrib import admin
# Register your models here.
from .models import Image
from .models import User
from .models import Admin
admin.site.register(User)
admin.site.register(Admin)
admin.site.register(Image)