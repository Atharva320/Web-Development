import pymysql
from flask import Flask, redirect, url_for, request
app = Flask(__name__)

@app.route('/success/<name>')
def success(name):
    con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
    curs=con.cursor()
    curs.execute("select * from Customers where CustomerId='%s'"%(name))
    rec=curs.fetchone()
    dic={}
    dic['Firstname']=rec[0]
    dic['Lastname']=rec[1]
    dic['Email']=rec[2]
    dic['Mobile']=rec[3]
    dic['City']=rec[4]
    dic['Age']=rec[5]
    return dic

@app.route('/ID',methods = ['POST', 'GET'])
def login():
    if request.method == 'POST':
        user = request.form['nm']
        return redirect(url_for('success',name = user))
    else:
        user = request.args.get('nm')
        return redirect(url_for('success',name = user))

if __name__ == '__main__':
    app.run(debug = True)
