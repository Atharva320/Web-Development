import pymysql
from flask import Flask, redirect, url_for, request
app = Flask(__name__)

@app.route('/success/<name>')
def succ(name):
    con=pymysql.connect(host='localhost',user='root',password='123456789',database='Djangodb')
    curs=con.cursor()
    curs.execute("select * from Cars where CarName='%s'"%(name))
    rec=curs.fetchone()
    dic={}
    dic['Car name']=rec[6]
    dic['Car type']=rec[5]
    dic['Price']=rec[4]
    dic['Fuel']=rec[3]
    dic['Company']=rec[2]
    dic['Capacity']=rec[1]
    dic['Wheels']=rec[0]
    return dic

@app.route('/Car',methods = ['POST', 'GET'])
def Car():
    if request.method == 'POST':
        user = request.form['nm']
        return redirect(url_for('succ',name = user))
    else:
        user = request.args.get('nm')
        return redirect(url_for('succ',name = user))

if __name__ == '__main__':
    app.run(debug = True)
